package com.mangashop.controller;

import com.mangashop.model.Role;
import com.mangashop.model.User;
import com.mangashop.service.RoleService;
import com.mangashop.service.UserService;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import java.util.function.BiConsumer;

@WebServlet(urlPatterns = "/users")
public class UserServlet extends HttpServlet {


    private UserService userService;
    private RoleService roleService;
    private String errors = "";

    @Override
    public void init() throws ServletException {
        userService = new UserService();
         roleService = new RoleService();
        if (this.getServletContext().getAttribute("roleList") == null) {
            this.getServletContext().setAttribute("roleList", roleService.selectRole());
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("hello");

        String action = req.getParameter("action");
        if (action == null) {
            action = "";
        }
        try {
            switch (action) {
                case "create":
                    showNewForm(req, resp);
                    break;
                case "edit":
                    showFormEdit(req, resp);
                    break;
                case "delete":
                    deleteUsers(req, resp);
                    break;
                default:
//                    listUser(req, resp);
                    listUserPaging(req, resp);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }

    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        User user = new User();
        request.setAttribute("user", user);
        RequestDispatcher dispatcher = request.getRequestDispatcher("user/create1.jsp");
        dispatcher.forward(request, response);
    }

    private void deleteUsers(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        int id = Integer.parseInt(request.getParameter("id"));
         userService.deleteUser(id);


        response.sendRedirect("/users");
//        List<User> listUser = userService.selectAllUsers();
//        request.setAttribute("listUser", listUser);
//        RequestDispatcher dispatcher = request.getRequestDispatcher("user/index.jsp");
//        dispatcher.forward(request, response);
    }

    private void showFormEdit(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        User users = userService.selectUser(id);
        RequestDispatcher dispatcher = request.getRequestDispatcher("user/edit.jsp");
        request.setAttribute("user", users);
        dispatcher.forward(request, response);
    }

    public void listUser(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        List<User> listUser = userService.selectAllUsers();
        request.setAttribute("listUser", listUser);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/user/index.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if (action == null) {
            action = "";
        }
        try {
            switch (action) {
                case "create":
                    insertUser(req, resp);
                    break;
                case "edit":
                    updateUser(req, resp);
                    break;
                default:
                    listUser(req, resp);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    public void insertUser(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
//        Map<String, String> error = new HashMap<String, String>();
//        User user = new User();
//        boolean flag = false;
//
//        String name = request.getParameter("name");
//        String phone = request.getParameter("phone");
//        String password = request.getParameter("password");
//        String email = request.getParameter("email");
//        String address = request.getParameter("address");
//        int role = Integer.parseInt(request.getParameter("idRole"));
//        User newUser = new User(name, phone, password, email, address, role);
//        userService.insertUser(newUser);
//        RequestDispatcher dispatcher = request.getRequestDispatcher("user/create1.jsp");
//        dispatcher.forward(request, response);
        User user = new User();
        boolean flag = true;
        Map<String, String> hashMap = new HashMap<String, String>();  // Luu lai truong nao bi loi va loi gi

        System.out.println(this.getClass() + " insertUser with validate");
        try {
            user.setId(Integer.parseInt(request.getParameter("id")));
            String name = request.getParameter("name");
            user.setName(name);
            String phone = request.getParameter("phone");
            user.setPhone(phone);
            user.setPassword(request.getParameter("password"));
            user.setAddress(request.getParameter("address"));
            String email = request.getParameter("email");
            user.setEmail(email);
            user.setId(Integer.parseInt(request.getParameter("idRole")));
            ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
            Validator validator = validatorFactory.getValidator();

            Set<ConstraintViolation<User>> constraintViolations = validator.validate(user);

            System.out.println("User: " + user);

            if (!constraintViolations.isEmpty()) {

                errors  = "<ul>";
                for (ConstraintViolation<User> constraintViolation : constraintViolations) {
                    errors += "<li>" + constraintViolation.getPropertyPath() + " " + constraintViolation.getMessage()
                            + "</li>";
                }
                errors += "</ul>";


                request.setAttribute("user", user);
                request.setAttribute("errors", errors);

                List<Role> roleList = roleService.selectRole();
                request.setAttribute("roleList", roleList);

                System.out.println(this.getClass() + " !constraintViolations.isEmpty()");
                request.getRequestDispatcher("/user/create1.jsp").forward(request, response);
            }else{
                if(userService.exitsByEmail(email)!=null) {
                    flag = false;
                    hashMap.put("email", "Email exits in database");
                    System.out.println(this.getClass() + " Email exits in database");
                }

                if(userService.existByPhone(phone)!=null) {
                    flag = false;
                    hashMap.put("phone", "Phone exits in database");
                    System.out.println(this.getClass() + " Phone exits in database");
                }
                if(flag) {
                    // Create user susscess
                    userService.insertUser(user);


                    User u = new User();
                    request.setAttribute("user", u);

                    request.getRequestDispatcher("user/create1.jsp").forward(request, response);
                }else {
                    // Error : Email exits in database
                    // Error: Country invalid
                    errors = "<ul>";
                    // One more field has error
                    hashMap.forEach(new BiConsumer<String, String>() {
                        @Override
                        public void accept(String keyError, String valueError) {
                            errors += "<li>"  + valueError+ "</li>";

                        }
                    });
                    errors +="</ul>";

                    request.setAttribute("user", user);
                    request.setAttribute("errors", errors);


                    System.out.println(this.getClass() + " !constraintViolations.isEmpty()");
                    request.getRequestDispatcher("/user/create1.jsp").forward(request, response);
                }


            }
        }
        catch (NumberFormatException ex) {
            System.out.println(this.getClass() + " NumberFormatException: User info from request: " + user);
            errors = "<ul>";
            errors += "<li>" + "format not right" + "</li>";
            errors += "</ul>";


            request.setAttribute("user", user);
            request.setAttribute("errors", errors);

            request.getRequestDispatcher("/user/create1.jsp").forward(request, response);
        }
        catch(Exception ex){

        }

        }

        public void updateUser (HttpServletRequest request, HttpServletResponse response) throws
        SQLException, IOException, ServletException {
            int id = Integer.parseInt(request.getParameter("id"));
            String name = request.getParameter("name");
            String phone = request.getParameter("phone");
            String password = request.getParameter("password");
            String email = request.getParameter("email");
            String address = request.getParameter("address");
            int role = Integer.parseInt(request.getParameter("idRole"));
            User newUser = new User(id, name, phone, password, email, address, role);
            userService.updateUser(newUser);
            RequestDispatcher dispatcher = request.getRequestDispatcher("user/edit.jsp");
            dispatcher.forward(request, response);
        }

        private void listUserPaging (HttpServletRequest request, HttpServletResponse response) throws
        ServletException, IOException {
            int page = 1;
            int recordsPerPage = 3;
//        String q = "";
//        int idrole = -1;
//        if (request.getParameter("q") != null) {
//            q = request.getParameter("q");
//        }
//        if (request.getParameter("idrole") != null) {
//            idrole = Integer.parseInt(request.getParameter("idrole"));
//        }
            if (request.getParameter("page") != null)
                page = Integer.parseInt(request.getParameter("page"));
            List<User> listUser = userService.selectUsersPaging((page - 1) * recordsPerPage, recordsPerPage);
            int noOfRecords = userService.getNoOfRecords();
            int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);

            System.out.println("sout" + noOfPages + "recod" + noOfRecords);
            request.setAttribute("listUser", listUser);
            request.setAttribute("noOfPages", noOfPages);
            request.setAttribute("currentPage", page);
//        request.setAttribute("q", q);
//        request.setAttribute("idrole", idrole);
            RequestDispatcher dispatcher = request.getRequestDispatcher("user/index.jsp");
            dispatcher.forward(request, response);
        }
    }
